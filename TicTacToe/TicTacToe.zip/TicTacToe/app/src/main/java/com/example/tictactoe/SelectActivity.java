package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.os.Bundle;

public class SelectActivity extends AppCompatActivity {
    boolean isSelected = false;
    boolean isEnabled = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select);
    }
    //-----------------------------
    //choose piece button code
    //-----------------------------
    public void btnO(View view){
        isEnabled = true;
        isSelected = true;
    }

    public void btnX(View view){
        isSelected = false;
        isEnabled = true;
    }
    //-----------------------------
    //choose difficulty button code
    //-----------------------------
    public void btnEasy(View view){
        if(isEnabled) {
            //P1GameActivity.isX = isSelected;
            //P1GameActivity.intLevel = 0;
            Intent i = new Intent(this, P1GameActivity.class);
            startActivity(i);
        }
    }

    public void btnMedium(View view){
        if(isEnabled) {
            //P1GameActivity.isX = isSelected;
            //P1GameActivity.intLevel = 1;
            Intent i = new Intent(this, P1GameActivity.class);
            startActivity(i);
        }
    }

    public void btnHard(View view){
        if(isEnabled) {
            //P1GameActivity.isX = isSelected;
            //P1GameActivity.intLevel = 2;
            Intent i = new Intent(this, P1GameActivity.class);
            startActivity(i);
        }
    }
}
