package com.example.tictactoe;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.GridLayout;
import android.widget.ImageView;

public class P1GameActivity extends AppCompatActivity {
    static Boolean isX;
    static int intLevel;
    //@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_p1);
    }

    public void btnB1(View view){

    }
    public void btnB2(View view){

    }
    public void btnB3(View view){

    }
    public void btnB4(View view){

    }
    public void btnB5(View view){

    }
    public void btnB6(View view){

    }
    public void btnB7(View view){

    }
    public void btnB8(View view){

    }
    public void btnB9(View view){

    }
}
