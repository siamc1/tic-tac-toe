package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.os.Bundle;

public class P2GameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p2_game);
    }
    public void btnB1(View view){

    }
    public void btnB2(View view){

    }
    public void btnB3(View view){

    }
    public void btnB4(View view){

    }
    public void btnB5(View view){

    }
    public void btnB6(View view){

    }
    public void btnB7(View view){

    }
    public void btnB8(View view){

    }
    public void btnB9(View view){

    }
}
